const redux =require('redux')
const createStore =redux.createStore
const buy_Tv='Buy_TV'
const buy_AC='Buy_AC'
function buytv(){
    return {
        type: buy_Tv,
        info: "first Action"
    }
}
function buyac(){
    return {
        type: buy_AC,
        info: "first Action"
    }
}

const initialstate ={
    nooftvs :10,
    noofac:20
}
const reducer = (state=initialstate,action)=>{
    switch (action.type) {
        case buy_Tv:
            return{
                ...state,
                nooftvs:state.nooftvs-1,
                
            }
            case buy_AC:
                return{
                    ...state,
                    noofac:state.noofac-1,
                    
                }
            default:return state
    
}
}
const store = createStore(reducer)
console.log("Initialstate:",store.getState())

const unsubscribe=store.subscribe(()=>console.log(" updatedstate :",store.getState()))
store.dispatch(buytv())
store.dispatch(buytv())
store.dispatch(buytv())
store.dispatch(buyac())
unsubscribe()